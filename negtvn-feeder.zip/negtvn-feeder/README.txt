negtvn.xyz captcha feeder
=========================

Everything is ready to use. You do not need to create any file.

1. Open config.json and paste your API key from the negtvn.xyz dashboard
   into "api_key". Save.
2. (cookie.txt mode) Put your accounts in data/cookie.txt, one per line.
3. Double-click negtvn-feeder.exe and pick a mode.

The tool only sends accounts that actually need a captcha, submits one
account per job, and prints a solved/failed line for each job when the
result comes back.
